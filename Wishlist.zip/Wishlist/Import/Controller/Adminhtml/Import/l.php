   // try
                        // {

                                
                        //         $collection=$this->wishlistFactory->create();
                        //         // $collection->setProductId(1);
                        //         // $collection->setWishlistId(1);
                        //         // $collection->setStoreId(1);
                        //         // $collection->save();
                        //         $collection->loadByCustomerId(1,)


                        //         // $collection->setWishlistId($dara[0]);

                        //         // $collection->setProductId($data[1]);
                        //         // // $collection->generateSharingCode();
                        //         // $collection->addNewItem($data[3]);
                        //         // $collection->save();
                        //         print_r(get_class_methods($collection));




                        // }
                        // catch(Exception $e)
                        // {
                        //     echo "error";
                        // }   
                           // if($count==0)
                        // {
                        //     //skip column
                        //     continue;
                        // }