<?php

namespace Wishlist\Import\Model\ResourceModel\Wishlist;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
    protected $_idFieldName = 'wishlist_id';
    public function _construct()
    {
        $this->_init('Wishlist\Import\Model\Wishlist', 'Wishlist\Import\Model\ResourceModel\Wishlist');
    }
}