<?php

namespace Wishlist\Import\Model;

class Wishlist extends \Magento\Framework\Model\AbstractModel
{
    public function _construct()
    {
        $this->_init('Wishlist\Import\Model\ResourceModel\Wishlist');
    }
}
